#ifndef CONTROLER_H_INCLUDED
#define CONTROLER_H_INCLUDED


#endif // CONTROLER_H_INCLUDED

int controller_leerArchivoClientes(char* path, ArrayList* pArrayClientes);
